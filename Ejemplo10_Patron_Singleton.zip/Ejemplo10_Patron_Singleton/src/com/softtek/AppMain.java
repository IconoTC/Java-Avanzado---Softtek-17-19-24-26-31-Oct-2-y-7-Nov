package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		Contabilidad libro1 = Contabilidad.getInstance();
		Contabilidad libro2 = Contabilidad.getInstance();
		
		// Comprobamos si es la misma instancia
		System.out.println("Es la misma instancia?? " + (libro1 == libro2));

	}

}
