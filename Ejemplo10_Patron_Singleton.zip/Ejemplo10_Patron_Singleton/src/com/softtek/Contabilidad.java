package com.softtek;

public class Contabilidad {
	
	// propiedad que almacena la unica instancia de la clase
	private static Contabilidad instance = null;
	
	// constructor privado
	private Contabilidad() {
		
	}
	
	// metodo publico y estatico que devuelva la unica instancia
	public static Contabilidad getInstance() {
		if (instance == null) {
			instance = new Contabilidad();
		}
		return instance;
	}
	
	// Metodos de negocio
	// Pagar nominas
	// Amortizacion de maquinaria
	// .....
}
  