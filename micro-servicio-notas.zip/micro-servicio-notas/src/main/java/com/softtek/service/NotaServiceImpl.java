package com.softtek.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.clients.AlumnoClienteFeign;
import com.softtek.models.Alumno;
import com.softtek.models.Nota;

@Service
public class NotaServiceImpl implements INotaService{
	
	@Autowired
	private AlumnoClienteFeign clienteFeign;

	@Override
	public Nota crearNota(Long id, String asignatura, double calificacion) {
		Alumno alumno = clienteFeign.buscar(id);
		return new Nota(alumno, asignatura, calificacion);
	}

}
