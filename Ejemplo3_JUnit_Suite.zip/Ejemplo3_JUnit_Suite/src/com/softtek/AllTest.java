package com.softtek;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({NumerosPrimosTest.class, ProcesarTextosTest.class})
public class AllTest {
	
	@BeforeClass
	public static void antes() {
		System.out.println("Inicio suite");
	}
	
	@AfterClass
	public static void despues() {
		System.out.println("Final suite");
	}

}
