package com.softtek;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ProcesarTextosTest {
	
	@BeforeClass
	public static void antesClase() {
		System.out.println("Inicio clase ProcesarTextosTest");
	}
	
	@AfterClass
	public static void despuesClase() {
		System.out.println("Fin clase ProcesarTextosTest");
	}
	
	@Before
	public void antes() {
		System.out.println("Se va a iniciar la prueba");
	}
	
	@After
	public void despues() {
		System.out.println("Se ha finalizado la prueba");
	}
	
	@Test
	public void pruebaLongitud() {
		System.out.println("Prueba longitud");
		String texto = "Hola";
		ProcesarTextos instance = new ProcesarTextos();
		int esperado = 4;
		int resultado = instance.longitud(texto);
		assertEquals(esperado, resultado);
	}
	
	@Test
	public void pruebaMayusculas() {
		System.out.println("Prueba mayusculas");
		String texto = "Hola";
		ProcesarTextos instance = new ProcesarTextos();
		String esperado = "HOLA";
		String real = instance.mayusculas(texto);
		assertEquals(esperado, real);
	}
	
	@Test
	public void pruebaMinusculas() {
		System.out.println("Prueba minusculas");
		String texto = "Hola";
		ProcesarTextos instance = new ProcesarTextos();
		String esperado = "hola";
		String real = instance.minusculas(texto);
		assertEquals(esperado, real);
	}

}
