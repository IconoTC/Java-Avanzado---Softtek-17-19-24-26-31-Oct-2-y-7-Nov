package com.softtek;

public class ProcesarTextos {
	
	public int longitud(String texto) {
		return texto.length();
	}
	
	public String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	public String minusculas(String texto) {
		return texto.toLowerCase();
	}

}
