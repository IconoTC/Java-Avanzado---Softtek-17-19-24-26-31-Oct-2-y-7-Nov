package com.softtek;


import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class NumerosPrimosTest {
	
	// Se ejecuta una vez al inicio de la clase
	@BeforeClass
	public static void inicioClase() {
		// Abrir log
		// Abrir la conexion
		// .....
		System.out.println("Se comienza a ejecutar la clase NumerosPrimosTest");
	}
	
	// Se ejecuta una vez al final de la clase
	@AfterClass
	public static void finClase() {
		// Cerrar log
		// Cerrar la conexion
		// .....
		System.out.println("Se termina de ejecutar la clase NumerosPrimosTest");
	}
	
	// Se ejecuta antes de cada prueba
	@Before
	public void antes() {
		System.out.println("Se va a ejecutar la prueba");
	}
	
	// Se ejecuta despues de cada prueba
	@After
	public void despues() {
		System.out.println("Se ha ejecutado la prueba");
	}	
	
	@Test
	public void testEsPrimo() {
		System.out.println("Probando si el numero es primo");
		int numero = 7;
		NumerosPrimos instance = new NumerosPrimos();
		boolean esperado = true;
		boolean realidad = instance.esPrimo(numero);
		assertEquals(esperado, realidad);
	}

}
