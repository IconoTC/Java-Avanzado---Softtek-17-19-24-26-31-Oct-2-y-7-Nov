package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		for(Conexion con: new PoolConexiones().getPool()) {
			System.out.println(con);
		}
	}

}
