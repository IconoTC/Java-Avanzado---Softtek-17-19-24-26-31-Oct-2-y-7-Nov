package com.softtek;

// El prototype debe ser clonable
public class Conexion implements Cloneable{
	
	private String driver = "com.mysql.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/softtek";
	private String user = "root";
	private String pw = "";
	
	// Guardar la unica instancia como prototipo
	private static Conexion prototipo = new Conexion();
	
	// Anulamos el contructor de la clase
	private Conexion() {
		// TODO Auto-generated constructor stub
	}
	
	// Metodo que devuelve el prototipo
	public static Conexion getPrototipo() {
		return prototipo;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		System.out.println("Clonando la conexion");
		return super.clone();
	}

	@Override
	public String toString() {
		return "Conexion [driver=" + driver + ", url=" + url + ", user=" + user + ", pw=" + pw + "]";
	}
	
	

}
