package com.softtek;

import java.util.ArrayList;
import java.util.List;

public class PoolConexiones {
	
	private List<Conexion> pool = new ArrayList<Conexion>();
	
	public List<Conexion> getPool(){
		// Recuperar el prototipo para clonarlo
		Conexion con = Conexion.getPrototipo();
		
		// Crear 10 conexiones
		for(int i=1; i<=10; i++) {
			try {
				pool.add((Conexion) con.clone());
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return pool;
	}

}
