package com.softtek;

public class AspectoTimer implements Servicio{
	
	private Servicio objeto;
	
	public AspectoTimer(Servicio objeto) {
		this.objeto = objeto;
	}

	@Override
	public void ejecutar() {
		System.out.println("Tomando tiempo de inicio");
		long inicio = System.nanoTime();
		
		objeto.ejecutar();
		
		long fin = System.nanoTime();
		System.out.println("Tiempo de respuesta: " + (fin - inicio) + " nanoseg.");
	}

}
