package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		Servicio negocio = new LogicaNegocio();
		negocio = new AspectoTimer(negocio);
		negocio = new AspectoLog(negocio);
		negocio.ejecutar();
	}

}
