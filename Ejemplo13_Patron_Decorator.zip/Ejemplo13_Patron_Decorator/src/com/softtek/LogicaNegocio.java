package com.softtek;

public class LogicaNegocio implements Servicio{

	@Override
	public void ejecutar() {
		System.out.println("----------------------");
		System.out.println("Lanzando peticion a SW");
		System.out.println("Consulta a la BBDD");
		System.out.println("Procesar la respuesta");
		System.out.println("----------------------");
	}
	
	

}
