package com.softtek;

public class AspectoLog implements Servicio{
	
	private Servicio objeto;
	
	public AspectoLog(Servicio objeto) {
		this.objeto = objeto;
	}

	@Override
	public void ejecutar() {
		System.out.println("Escribiendo en el log " + objeto);
		objeto.ejecutar();
		
	}

}
