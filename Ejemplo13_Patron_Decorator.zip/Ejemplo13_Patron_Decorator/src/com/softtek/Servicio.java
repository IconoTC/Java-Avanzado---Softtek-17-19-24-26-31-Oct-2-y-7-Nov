package com.softtek;

public interface Servicio {
	
	public void ejecutar();

}
