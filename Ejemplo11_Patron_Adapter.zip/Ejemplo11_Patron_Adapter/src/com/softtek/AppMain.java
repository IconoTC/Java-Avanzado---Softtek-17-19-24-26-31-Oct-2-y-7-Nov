package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		FechaUS fechaUS = new FechaUS(11, 2, 2023);
		System.out.println("Fecha en formato americano: " + fechaUS);
		
		// Adaptar la fecha a formato español
		Fecha fecha = new AdaptadorFecha(fechaUS);
		
		System.out.println("Fecha adaptada a español: " + fecha);

	}

}
