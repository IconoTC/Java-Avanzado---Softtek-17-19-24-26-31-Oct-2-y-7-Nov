package com.softtek;

public class AdaptadorFecha implements Fecha {

	private FechaUS fechaUS;

	public AdaptadorFecha(FechaUS fechaUS) {
		super();
		this.fechaUS = fechaUS;
	}

	@Override
	public int getDia() {
		return fechaUS.getDay();
	}

	@Override
	public void setDia(int dia) {
		fechaUS.setDay(dia);
	}

	@Override
	public int getMes() {
		return fechaUS.getMonth();
	}

	@Override
	public void setMes(int mes) {
		fechaUS.setMonth(mes);
	}

	@Override
	public int getAnyo() {
		return fechaUS.getYear();
	}

	@Override
	public void setAnyo(int anyo) {
		fechaUS.setYear(anyo);
	}

	@Override
	public String toString() {
		return getDia() + "/" + getMes() + "/" + getAnyo();
	}
	
	

}
