package com.softtek;

public interface Fecha {
	
	public int getDia();
	public void setDia(int dia);
	
	public int getMes();
	public void setMes(int mes);
	
	public int getAnyo();
	public void setAnyo(int anyo);

}
