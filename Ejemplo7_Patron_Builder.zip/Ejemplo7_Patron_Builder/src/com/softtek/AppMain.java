package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		// En Java los String son inmutables
		String nombre = "Pepito";
		
		// A partir de Java 5 incluye la clase StringBuilder que es mutable
		StringBuilder  builder = new StringBuilder("Pepito");
		builder.append(" ");
		builder.append("Perez");
		builder.append(" ");
		builder.append("Gonzalez");
		
		System.out.println(builder);
	}

}
