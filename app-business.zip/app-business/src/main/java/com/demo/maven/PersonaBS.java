package com.demo.maven;

public class PersonaBS {
	
	public String hashNombre(String nombre, String apellido) {
		
		if (nombre == null) {
			throw new RuntimeException("El nombre no puede ser nulo");
		}
		
		if (apellido == null) {
			throw new RuntimeException("El apellido no puede ser nulo");
		}
		
		return HashUtil.hash(nombre, apellido);
	}

}
