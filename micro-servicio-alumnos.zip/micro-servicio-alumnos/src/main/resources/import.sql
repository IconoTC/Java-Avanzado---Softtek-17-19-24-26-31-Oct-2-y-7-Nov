insert into ALUMNOS (NOMBRE, APELLIDO) values ('Juan', 'Perez');
insert into ALUMNOS (NOMBRE, APELLIDO) values ('Maria', 'Lopez');
insert into ALUMNOS (NOMBRE, APELLIDO) values ('Luis', 'Sanchez');
insert into ALUMNOS (NOMBRE, APELLIDO) values ('Paula', 'Rodriguez');