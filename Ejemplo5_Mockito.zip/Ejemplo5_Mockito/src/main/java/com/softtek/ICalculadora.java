package com.softtek;

public interface ICalculadora {

	int sumar();
	
}
