package com.softtek;

public interface INumerosService {
	
	int[] getNumeros();

}
