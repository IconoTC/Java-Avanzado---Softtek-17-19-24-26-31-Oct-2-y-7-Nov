package com.softtek;

public class NumerosServiceImpl implements INumerosService{

	@Override
	public int[] getNumeros() {
		int[] numeros = {7,1,4,9,3};
		return numeros;
	}

}
