package com.softtek;

public class CalculadoraImpl implements ICalculadora{
	
	private INumerosService service;

	@Override
	public int sumar() {
		int suma = 0;
		
		for(int num : service.getNumeros()) {
			suma += num;
		}
		return suma;
	}
	
	public void setService(INumerosService service) {
		this.service = service;
	}

}
