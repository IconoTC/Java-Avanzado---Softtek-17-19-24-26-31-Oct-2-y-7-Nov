package com.softtek;

public class ServicioXML implements Servicio{

	@Override
	public String obtenerDatos(int id) {
		// Simulamos una conedxion a la BBDD
		// donde buscamos el registro con ese id
		// y el resultado de la informacion se 
		// devuelve en formato XML 
		return "<?xml version='1.0' encoding='UTF-8' ?>"+
		       "<cliente>" +
				  "<id>" + id + "</id>" +
		          "<nombre> Juan </nombre>" +
		       "</cliente>"; 	
	}
	
	

}
