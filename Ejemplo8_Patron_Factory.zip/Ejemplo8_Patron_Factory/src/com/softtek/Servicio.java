package com.softtek;

public interface Servicio {
	
	public String obtenerDatos(int id);

}
