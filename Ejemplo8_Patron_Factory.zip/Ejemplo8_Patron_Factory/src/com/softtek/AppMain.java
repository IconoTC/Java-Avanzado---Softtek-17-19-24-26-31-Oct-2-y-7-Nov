package com.softtek;

public class AppMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Servicio service = ServicioFactory.create("xml");
		System.out.println(service.obtenerDatos(4));
		
		service = ServicioFactory.create("json");
		System.out.println(service.obtenerDatos(4));

	}

}
