package com.softtek;

public class ServicioFactory {
	
	public static Servicio create(String formato) throws Exception{
		
		switch (formato.toLowerCase()) {
		case "xml":
			return new ServicioXML();
			
		case "json":
			return new ServicioJSON();	

		default:
			throw new Exception("Formato desconocido");
		}
	}

}
