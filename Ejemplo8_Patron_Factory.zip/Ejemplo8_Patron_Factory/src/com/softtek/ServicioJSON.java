package com.softtek;

public class ServicioJSON implements Servicio{

	@Override
	public String obtenerDatos(int id) {
		// Simulamos una conedxion a la BBDD
		// donde buscamos el registro con ese id
		// y el resultado de la informacion se 
		// devuelve en formato JSON 
		return "{id: " + id + ", nombre: 'Juan'}";
	}
	
	

}
