package com.softtek;

public class Numeros {
	
	// Un método para que pueda ser probado tiene que devolver un valor
	// porque sino es imposible de testear
	public boolean esPositivo(int num) {
		if (num >= 0) {
			return true;
		} else {
			return false;
		}
	}

}
