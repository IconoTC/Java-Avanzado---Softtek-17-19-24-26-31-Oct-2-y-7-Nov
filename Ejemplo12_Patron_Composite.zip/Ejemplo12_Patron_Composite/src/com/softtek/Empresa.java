package com.softtek;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
	
	private String nombre;
	private List<Empleado> empleados = new ArrayList<>();
	private List<Proyecto> proyectos = new ArrayList<>();
	
	public Empresa() {
		// TODO Auto-generated constructor stub
	}

	public Empresa(String nombre, List<Empleado> empleados, List<Proyecto> proyectos) {
		super();
		this.nombre = nombre;
		this.empleados = empleados;
		this.proyectos = proyectos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}

	public List<Proyecto> getProyectos() {
		return proyectos;
	}

	public void setProyectos(List<Proyecto> proyectos) {
		this.proyectos = proyectos;
	}

	@Override
	public String toString() {
		return "Empresa [nombre=" + nombre + ", empleados=" + empleados + ", proyectos=" + proyectos + "]";
	}
	
	

}
