package com.softtek;

import java.util.ArrayList;
import java.util.List;

public class Proyecto {
	
	private String nombre;
	private List<Empleado> equipo = new ArrayList<>();
	
	public Proyecto() {
		// TODO Auto-generated constructor stub
	}

	public Proyecto(String nombre, List<Empleado> equipo) {
		super();
		this.nombre = nombre;
		this.equipo = equipo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Empleado> getEquipo() {
		return equipo;
	}

	public void setEquipo(List<Empleado> equipo) {
		this.equipo = equipo;
	}

	@Override
	public String toString() {
		return "Proyecto [nombre=" + nombre + ", equipo=" + equipo + "]";
	}
	
	

}
