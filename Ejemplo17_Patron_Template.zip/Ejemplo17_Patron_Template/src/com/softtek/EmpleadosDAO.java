package com.softtek;

import java.util.List;

public class EmpleadosDAO extends DAOGenerico<Empleado>{

	@Override
	public void abrirConexion() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cerrarConexion() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Empleado alta(Empleado obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Empleado> consultarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Empleado buscar(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

}
