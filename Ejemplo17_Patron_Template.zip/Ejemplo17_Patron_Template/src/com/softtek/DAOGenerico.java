package com.softtek;

import java.sql.Connection;
import java.util.List;

public abstract class DAOGenerico<E> {
	
	private Connection conection;
	
	public abstract void abrirConexion();
	public abstract void cerrarConexion();
	
	public abstract E alta(E obj);
	public abstract List<E> consultarTodos();
	public abstract E buscar(Object object);


}
