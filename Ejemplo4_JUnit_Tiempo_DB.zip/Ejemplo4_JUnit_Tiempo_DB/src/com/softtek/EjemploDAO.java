package com.softtek;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class EjemploDAO {
	
	private Connection con;
	
	public void abrirConexion() {
		
		try {
			// Cargar el driver de la BBDD
			Class.forName("com.mysql.jdbc.Driver");
			
			// Obtener la conexion a partir de ese driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/softtek", "root", "");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
