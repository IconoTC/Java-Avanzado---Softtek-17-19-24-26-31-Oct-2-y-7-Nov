package com.softtek;

import org.junit.Test;

public class EjemploDAOTest {
	
	@Test
	public void test() {
		
		// Tomamos el tiempo de inicio
		long tiempoInicio = System.currentTimeMillis();
		
		// Instancia del DAO
		EjemploDAO dao = new EjemploDAO();
		
		// Abrir la conexion
		dao.abrirConexion();
		
		// Tomamos el tiempo final
		long tiempoFinal = System.currentTimeMillis();
		
		// Tiempo que tarda en abrir la conexion
		long tiempo = tiempoFinal - tiempoInicio;
		
		// Prueba: si es superior a 0,5 mseg lo damos por error
		if (tiempo > 500) {
			assert false;
		}
		
	}

}
