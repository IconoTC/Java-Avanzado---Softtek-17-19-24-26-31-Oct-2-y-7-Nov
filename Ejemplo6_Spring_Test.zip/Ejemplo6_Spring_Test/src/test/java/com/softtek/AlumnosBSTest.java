package com.softtek;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import com.softtek.business.AlumnosBS;

@SpringBootTest
public class AlumnosBSTest {
	
	@Autowired
	private AlumnosBS alumnosBS;
	
	@Test
	public void prueba() {
		System.out.println("Probando cuantos alumnos tengo suspensos");
		
		int esperado = 2;
		int real = alumnosBS.procesarAlumnos();
		
		Assert.isTrue(esperado == real);
		
	}

}
