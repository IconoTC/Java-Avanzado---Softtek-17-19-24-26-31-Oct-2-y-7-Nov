package com.softtek.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.softtek.models.Alumno;

@Component
public class AlumnosUtil {
	
	public List<Alumno> getAlumnos(){
		List<Alumno> lista = new ArrayList<Alumno>();
		lista.add(new Alumno("Pedro", 8.5));
		lista.add(new Alumno("Juan", 3.7));
		lista.add(new Alumno("Maria", 6.4));
		lista.add(new Alumno("Andres", 5.9));
		lista.add(new Alumno("Lucia", 3.2));
		lista.add(new Alumno("Sofia", 10));
		return lista;
	}

}
