package com.softtek.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.models.Alumno;
import com.softtek.util.AlumnosUtil;

@Service
public class AlumnosBS {
	
	@Autowired
	private AlumnosUtil util;
	
	public int procesarAlumnos() {
		int cuantosSuspensos = 0;
		
		for(Alumno alumno : util.getAlumnos()) {
			if (alumno.getNota() < 5) {
				cuantosSuspensos++;
			}
		}
		
		return cuantosSuspensos;
	}
	
}
