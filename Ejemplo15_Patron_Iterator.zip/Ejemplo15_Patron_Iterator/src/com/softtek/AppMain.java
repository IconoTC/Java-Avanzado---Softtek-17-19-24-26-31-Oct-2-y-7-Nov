package com.softtek;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		List<String> nombres = new LinkedList<String>();
		nombres.add("Pedro");
		nombres.add("Luis");
		nombres.add("Maria");
		nombres.add("Jorge");
		nombres.add("Andres");
		
		// Patron iterator
		Iterator<String> it = nombres.listIterator();
		while(it.hasNext()) {
			String nombre = it.next();
			System.out.println(nombre);
		}

	}

}
