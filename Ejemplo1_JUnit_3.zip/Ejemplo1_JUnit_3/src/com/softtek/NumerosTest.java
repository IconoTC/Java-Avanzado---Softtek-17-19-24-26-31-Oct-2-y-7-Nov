package com.softtek;

import junit.framework.TestCase;

// Con JUnit 3  -> escribimos codigo
// Con JUnit 4  -> Se utilizan anotaciones


// El nombre de la clase de prueba siempre es:
// El nombre de la clase a testear + Test
public class NumerosTest extends TestCase{
	
	long inicio = 0;
	long fin = 0;
	
	// Este metodo se ejecuta antes de cada prueba
	// cada uno de los metodos que tenemos en esta clase
	@Override
	protected void setUp() throws Exception {
		// Es interesante como prueba medir los tiempos de ejecucion
		inicio = System.currentTimeMillis();
		System.out.println("Tomando el tiempo de inicio");
	}
	
	
	// Este metodo se ejecuta despues de cada prueba
	@Override
	protected void tearDown() throws Exception {
		// Tomar el tiempo final y calcular la diferencia de tiempos
		fin = System.currentTimeMillis();
		System.out.println("El tiempo de la prueba es " + (fin - inicio) + " mseg.");
	}



	public void test() {
		
		System.out.println("Prueba si el numero es positivo");
		
		Numeros instance = new Numeros();
		
		// Vamos a probar con un numero negativo
		int num = -6;
		
		// Le indico como valor false porque si el numero es negativo, 
		// deberia devolver false
		boolean expResult = false;
		
		// Obtenemos el valor real
		boolean resultado = instance.esPositivo(num);
		
		// Comprobar si los resultados son iguales
		assertEquals(expResult, resultado);
		
	}

}
