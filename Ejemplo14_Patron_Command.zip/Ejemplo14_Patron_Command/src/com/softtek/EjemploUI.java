package com.softtek;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class EjemploUI {
	
	private JFrame frame;
	private JTextField campoTexto;
	private JLabel etiqueta;
	
	public void lanzarFrame() {
		etiqueta = new JLabel("Haz click y arrastra el raton");
		frame = new JFrame("Ejemplo movimiento del raton");
		campoTexto = new JTextField(30);
		
		frame.add(etiqueta, BorderLayout.NORTH);
		frame.add(campoTexto, BorderLayout.SOUTH);
		frame.setSize(800, 600);
		frame.addMouseMotionListener(new MyMouseMotionListener());
		frame.setVisible(true);
	}
	
	class MyMouseMotionListener extends MouseMotionAdapter{
		
		@Override
		public void mouseDragged(MouseEvent e) {
			String texto = "Coordenadas del raton: X=" + e.getX() + " Y=" + e.getY();
			campoTexto.setText(texto);
		}
	}

	public static void main(String[] args) {
		EjemploUI ui = new EjemploUI();
		ui.lanzarFrame();
	}

}
