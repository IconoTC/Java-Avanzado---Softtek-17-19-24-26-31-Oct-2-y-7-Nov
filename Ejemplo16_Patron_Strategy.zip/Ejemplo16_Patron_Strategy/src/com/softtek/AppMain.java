package com.softtek;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class AppMain {
	
	public static void main(String[] args) {
		// List es una interface
		// implementaciones de esta interface: ArrayList, LinkedList, AbstractList, Vector,...
		
		// Cada coleccion implementa una estrategia diferente en cuanto a recorrido, insertar, borrar
		List<String> lista1 = new ArrayList<String>();
		List<String> lista2 = new LinkedList<String>();
		List<String> lista4 = new Vector<String>();
		List<String> lista3 = new AbstractList<String>() {

			@Override
			public int size() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public boolean addAll(Collection<? extends String> c) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public String get(int index) {
				// TODO Auto-generated method stub
				return null;
			}
		};
		
	}
	

}
